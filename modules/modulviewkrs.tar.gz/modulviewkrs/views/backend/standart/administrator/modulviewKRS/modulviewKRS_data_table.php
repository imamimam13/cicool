<?php foreach($modulviewKRSs as $modulviewKRS): ?>
    <tr>
                <td width="5">
            <input type="checkbox" class="flat-red check" name="id[]" value="<?= $modulviewKRS->id_view; ?>">
        </td>
                
        <td width="200">
        
                        <?php is_allowed('modulviewKRS_view', function() use ($modulviewKRS){?>
                        <a href="<?= admin_site_url('/modulviewKRS/view/' . $modulviewKRS->id_view); ?>" data-id="<?= $modulviewKRS->id_view ?>" class="label-default btn-act-view"><i class="fa fa-newspaper-o"></i> <?= cclang('view_button'); ?>
            <?php }) ?>
            <?php is_allowed('modulviewKRS_update', function() use ($modulviewKRS){?>
            <a href="<?= admin_site_url('/modulviewKRS/edit/' . $modulviewKRS->id_view); ?>" data-id="<?= $modulviewKRS->id_view ?>" class="label-default btn-act-edit"><i class="fa fa-edit "></i> <?= cclang('update_button'); ?></a>
            <?php }) ?>
            <?php is_allowed('modulviewKRS_delete', function() use ($modulviewKRS){?>
            <a href="javascript:void(0);" data-href="<?= admin_site_url('/modulviewKRS/delete/' . $modulviewKRS->id_view); ?>" class="label-default remove-data"><i class="fa fa-close"></i> <?= cclang('remove_button'); ?></a>
            <?php }) ?>

        </td>    </tr>
    <?php endforeach; ?>
    <?php if ($modulviewKRS_counts == 0) :?>
        <tr>
        <td colspan="100">
        ModulviewKRS data is not available
        </td>
        </tr>
    <?php endif; ?>