<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['modulviewKRS'] = 'ModulviewKRS';
$lang['id_view'] = 'Id View';
